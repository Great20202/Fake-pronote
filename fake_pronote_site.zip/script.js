
document.getElementById("loginForm").addEventListener("submit", function(e) {
    e.preventDefault();
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    if (username === "irokz" && password === "admin123") {
        window.location.href = "admin.html";
    } else if (username === "sofiazaki" && password === "sofia2025") {
        window.location.href = "sofia.html";
    } else {
        document.getElementById("error-msg").innerText = "Identifiants incorrects.";
    }
});
